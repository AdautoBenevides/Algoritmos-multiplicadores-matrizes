import java.net.*;
import java.util.ArrayList;
import java.util.List;
import java.io.*;
import java.text.DecimalFormat;

public class TCPServer {
    public static void main(String[] args) {
        int serverPort = 7896;
        int numWorkers = 4;
        List<Socket> workerSockets = new ArrayList<>();

        try (ServerSocket listenSocket = new ServerSocket(serverPort)) {
            System.out.println("Servidor ouvindo a porta " + serverPort);

            // Aguarda todos os trabalhadores se conectarem
            while (workerSockets.size() < numWorkers) {
                Socket clientSocket = listenSocket.accept();
                System.out.println("Cliente conectado: " + clientSocket.getInetAddress().getHostAddress());
                workerSockets.add(clientSocket);
            }
            
            Connection connection = new Connection(workerSockets, numWorkers);
            connection.start();
            
            
            
        } catch (IOException e) {
            System.out.println("Erro ao iniciar o servidor: " + e.getMessage());
        }
    }

    static class Connection extends Thread {
        List<Socket> workerSockets;
        int numWorkers;

        public Connection(List<Socket> workerSockets, int numWorkers) {
            this.workerSockets = workerSockets;
            this.numWorkers = numWorkers;
        }

        public void run() {
        	long startTime = System.nanoTime();
        	
            int order = 64;
            
            int partSize = order / numWorkers;

            int[][] a = criarMatriz(order);
            int[][] b = criarMatriz(order);
            
            int[][] c = new int[order][order];
            
            try {
            	
                // Envia partes das matrizes para cada trabalhador
                for (int i = 0; i < numWorkers; i++) {
                    Socket workerSocket = workerSockets.get(i);
                    ObjectOutputStream out = new ObjectOutputStream(workerSocket.getOutputStream());

                    
                    // Divide a matriz A para cada trabalhador
                    int[][] aPart = new int[partSize][order];
                    System.arraycopy(a, i * partSize, aPart, 0, partSize);
                    
                    
                    
                    out.writeObject(aPart);
                    out.writeObject(b);

                    out.flush();  // Certifique-se de enviar tudo antes de fechar o stream
                    // Não feche o socket até que o trabalho esteja concluído
                }

                // Recebe as partes da matriz C dos trabalhadores
                for (int i = 0; i < numWorkers; i++) {
                    Socket workerSocket = workerSockets.get(1);  // Use o mesmo socket
                    ObjectInputStream in = new ObjectInputStream(workerSocket.getInputStream());

                    int[][] cPart = (int[][]) in.readObject();
                    int startRow = i * partSize;
                    
                    printMatrix(cPart);

                    System.arraycopy(cPart, 0, c, startRow, partSize);  // Copie para a matriz final
                    in.close();  // Feche o stream de entrada

                    workerSocket.close();  // Feche o socket após concluir a comunicação
                }

                // Imprime a matriz final
//                printMatrix(c);
                
                long endTime = System.nanoTime();
                long executionTime = endTime - startTime;

                double seconds = executionTime / 1000000000.0;

                System.out.println("Runtime: " + seconds + " seconds");

            } catch (IOException | ClassNotFoundException e) {
                System.out.println("Erro ao processar matrizes: " + e.getMessage());
            }
        }

        private static int[][] criarMatriz(int order) {
            int[][] matriz = new int[order][order];
            for (int row = 0; row < order; row++) {
                for (int column = 0; column < order; column++) {
                    matriz[row][column] = (row+1) * (column+1);
                }
            }
            return matriz;
        }

        private static void printMatrix(int[][] matrix) {
            for (int[] row : matrix) {
                for (int value : row) {
                    System.out.print(value + " ");
                }
                System.out.println();
            }
        }
    }
}
